package com.example.biancaionescu.history;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import android.text.format.DateFormat;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.Iterator;
import java.util.TimeZone;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {

    private FirebaseAuth firebaseAuth;

    private TextView textViewUserEmail;
    private Button buttonLogOut;
    private TextView mTextView;
    private TextView currentDate;

    private Date currentTime;
    private int day;
    private int month;
    private int year;


    private static final String TAG = "HomeActivity";

    public String url;
    public String int_url;

    private String createdDateCurrent;

    private TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        firebaseAuth = FirebaseAuth.getInstance();

        if(firebaseAuth.getCurrentUser() == null) {
            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }

        FirebaseUser user = firebaseAuth.getCurrentUser();


        Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
        day = calendar.get(Calendar.DAY_OF_MONTH);
        month = calendar.get(Calendar.MONTH)+1;
        year = calendar.get(Calendar.YEAR);


        int_url ="http://www.vizgr.org/historical-events/search.php?begin_date=";


        mDisplayDate = (TextView) findViewById(R.id.tvDate);
        currentDate = (TextView) findViewById(R.id.selectedDateDisplay);

        if (month < 10)
            if (day < 10)
                currentDate.setText("0" + day + "-0" + month + "-" + year);
            else
                currentDate.setText(day + "-0" + month + "-" + year);
        else
            if (day < 10)
                currentDate.setText("0" + day + "-" + month + "-" + year);
            else
                currentDate.setText("" + day + "-" + month + "-" + year);

        mDisplayDate.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                Calendar cal = Calendar.getInstance();
                                                int yearPicker = cal.get(Calendar.YEAR);
                                                int dayPicker = cal.get(Calendar.DAY_OF_MONTH)+1;
                                                int monthPicker = cal.get(Calendar.MONTH);

                                                DatePickerDialog dialog = new DatePickerDialog(
                                                        HomeActivity.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth, mDateSetListener, yearPicker, monthPicker, dayPicker);

                                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                                                dialog.show();

                                            }
                                        });
        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int yearPicker, int monthPicker , int dayPicker) {
                //Log.d(TAG, "OnDataSet: date: " + year + " " + month + " " + dayOfMonth );
                //mTextView.setText(yearPicker + " " + monthPicker);

                int realMonth = monthPicker + 1;

                if (realMonth < 10)
                    if (dayPicker < 10)
                        currentDate.setText("0" + dayPicker + "-0" + realMonth + "-" + yearPicker);
                    else
                        currentDate.setText(dayPicker + "-0" + realMonth + "-" + yearPicker);
                else
                if (day < 10)
                    currentDate.setText("0" + dayPicker + "-" + realMonth + "-" + yearPicker);
                else
                    currentDate.setText("" + dayPicker + "-" + realMonth + "-" + yearPicker);


                resultsOnAPI(dayPicker, realMonth, yearPicker, int_url);
            }
        };


        textViewUserEmail = (TextView) findViewById(R.id.textViewUserEmail);

        textViewUserEmail.setText("Welcome " +user.getEmail());
        buttonLogOut = (Button) findViewById(R.id.buttonLogout);

        buttonLogOut.setOnClickListener(this);

        mTextView = (TextView) findViewById(R.id.textViewDescription);


        resultsOnAPI(day, month, year, int_url);

    }

    @Override
    public void onClick(View view) {
        if(view == buttonLogOut) {
            firebaseAuth.signOut();
            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }
    }

    public void resultsOnAPI(int day, int month, int year, String url) {

        RequestQueue queue = Volley.newRequestQueue(this);
        String createdDate;

        if (month < 10)
            if (day < 0)
                createdDate = year + "0" + month + "0" + day;
            else
                createdDate = year + "0" + month + day;
        else
            if (day < 0)
                createdDate = year + month + "0" + day;
            else
                createdDate = "" + year + month + day;


        String newUrl = url + createdDate + "&end_date=" + createdDate + "&format=json";

        JsonObjectRequest objectRequest = new JsonObjectRequest(
                Request.Method.GET,
                newUrl,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("macaroane", response.toString());



                        try {
                            mTextView.setText(response.getJSONObject("result").getJSONObject("event").get("description").toString());
                            Log.e("Alex  ", response.getJSONObject("result").getJSONObject("event").get("date").toString());
                            Log.e("Alex  ", response.getJSONObject("result").getJSONObject("event").get("description").toString());
                        } catch (JSONException e) {
                            mTextView.setText("No events in the selected data");
                            e.printStackTrace();
                        }
                        //mTextView.setText("rasp");
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error", error.toString());
                        //mTextView.setText("eroare");
                    }
                }
        );

        queue.add(objectRequest);
    }
}
